"""
AXONIZE — ws_collector.py
WebSocket коллектор: подписка на kline_1m для топ-200 символов.
Автоматический реконнект, ping/pong, запись через asyncpg pool.
"""
import asyncio
import json
import gzip
import logging
import time
from datetime import datetime, timezone
from typing import Set, Dict, Optional
from collections import defaultdict, deque

import websockets
from websockets.exceptions import (
    ConnectionClosedError, ConnectionClosedOK, WebSocketException
)

import config
import database as db

logger = logging.getLogger("axonize.ws")

# ──────────────────────────────────────────────────────────────
#  Метрики (атомарные счётчики без asyncio.Lock — GIL даёт защиту)
# ──────────────────────────────────────────────────────────────
class Metrics:
    def __init__(self):
        self.msgs_total    = 0
        self.writes_total  = 0
        self.errors_total  = 0
        self.reconnects    = 0
        self.start_time    = time.time()
        self._msg_times: deque = deque(maxlen=1000)  # для RPS

    def record_msg(self):
        self.msgs_total += 1
        self._msg_times.append(time.time())

    def record_write(self):
        self.writes_total += 1

    def record_error(self):
        self.errors_total += 1

    @property
    def msgs_per_sec(self) -> float:
        if len(self._msg_times) < 2:
            return 0.0
        span = self._msg_times[-1] - self._msg_times[0]
        return len(self._msg_times) / span if span > 0 else 0.0

    @property
    def uptime_sec(self) -> int:
        return int(time.time() - self.start_time)


metrics = Metrics()

# ──────────────────────────────────────────────────────────────
#  BingX WS payload parser
# ──────────────────────────────────────────────────────────────

def decode_message(raw) -> Optional[dict]:
    """BingX шлёт gzip-сжатые бинарные фреймы."""
    try:
        if isinstance(raw, bytes):
            try:
                data = gzip.decompress(raw)
            except Exception:
                data = raw
            return json.loads(data.decode("utf-8"))
        return json.loads(raw)
    except Exception as e:
        logger.debug(f"Decode error: {e}")
        return None


def parse_kline(msg: dict) -> Optional[dict]:
    """
    BingX kline формат:
    {
      "code": 0,
      "dataType": "BTC-USDT@kline_1m",
      "data": {
        "T": 1699999999000,   # close time ms
        "t": 1699999940000,   # open time ms
        "o": "36000.0", "h": "36100.0", "l": "35900.0", "c": "36050.0",
        "v": "12.345",        # base vol
        "q": "445000.0",      # quote vol
        "n": 320,             # trades
        "x": false            # is_closed
      }
    }
    """
    try:
        data_type = msg.get("dataType", "")
        if "@kline" not in data_type:
            return None

        # "BTC-USDT@kline_1m" → "BTCUSDT"
        raw_sym = data_type.split("@")[0]
        symbol = raw_sym.replace("-", "")

        k = msg.get("data", {})
        if not k:
            return None

        return {
            "symbol":    symbol,
            "timeframe": "1m",
            "ts":        datetime.fromtimestamp(int(k["t"]) / 1000, tz=timezone.utc),
            "open":      float(k["o"]),
            "high":      float(k["h"]),
            "low":       float(k["l"]),
            "close":     float(k["c"]),
            "volume":    float(k["v"]),
            "quote_vol": float(k.get("q", 0)),
            "is_closed": bool(k.get("x", False)),
        }
    except Exception as e:
        logger.debug(f"parse_kline error: {e} | msg={msg}")
        return None


# ──────────────────────────────────────────────────────────────
#  Write buffer — буферизуем быстрые тики, пишем батчами
# ──────────────────────────────────────────────────────────────
class WriteBuffer:
    """
    Накапливает свечи и сбрасывает в БД:
    - каждые FLUSH_INTERVAL секунд, ИЛИ
    - когда накопилось FLUSH_SIZE строк
    Предотвращает лавину одиночных INSERT при 200 символах.
    """
    FLUSH_INTERVAL = 2.0   # секунд
    FLUSH_SIZE     = 500   # строк

    def __init__(self):
        # Хранит последнюю версию каждой (symbol, ts) — новый тик перезаписывает
        self._buffer: Dict[tuple, tuple] = {}
        self._last_flush = time.time()

    def add(self, candle: dict):
        key = (candle["symbol"], candle["ts"])
        self._buffer[key] = (
            candle["symbol"], candle["timeframe"], candle["ts"],
            candle["open"], candle["high"], candle["low"],
            candle["close"], candle["volume"], candle["quote_vol"],
            candle["is_closed"],
        )

    def should_flush(self) -> bool:
        return (
            len(self._buffer) >= self.FLUSH_SIZE or
            (time.time() - self._last_flush) >= self.FLUSH_INTERVAL
        )

    async def flush(self):
        if not self._buffer:
            return
        rows = list(self._buffer.values())
        self._buffer.clear()
        self._last_flush = time.time()
        try:
            await db.upsert_candles_bulk(rows)
            metrics.writes_total += len(rows)
            logger.debug(f"Flushed {len(rows)} candles to DB")
        except Exception as e:
            logger.error(f"DB flush error: {e}")
            metrics.record_error()


write_buffer = WriteBuffer()


# ──────────────────────────────────────────────────────────────
#  Subscription builder
# ──────────────────────────────────────────────────────────────

def build_subscribe_msg(symbols: list[str]) -> list[dict]:
    """
    BingX принимает подписку батчами.
    Разбиваем на группы по 50 символов.
    """
    msgs = []
    chunk_size = 50
    for i in range(0, len(symbols), chunk_size):
        chunk = symbols[i:i + chunk_size]
        args = [f"{s.replace('USDT', '-USDT')}@kline_1m" for s in chunk]
        msgs.append({
            "id":     f"sub_{i}",
            "reqType": "sub",
            "dataType": args,
        })
    return msgs


# ──────────────────────────────────────────────────────────────
#  Агрегатор-очередь для старших таймфреймов
# ──────────────────────────────────────────────────────────────
_agg_queue: Optional[asyncio.Queue] = None

def set_agg_queue(q: asyncio.Queue):
    global _agg_queue
    _agg_queue = q


# ──────────────────────────────────────────────────────────────
#  Главный WS loop
# ──────────────────────────────────────────────────────────────

async def run_ws_collector(symbols: list[str]):
    """
    Основной цикл WebSocket коллектора.
    При любом разрыве — реконнект через RECONNECT_DELAY_MS мс.
    """
    reconnect_delay = config.RECONNECT_DELAY_MS / 1000.0
    ping_interval   = config.WS_PING_INTERVAL_MS / 1000.0

    logger.info(f"WS collector starting for {len(symbols)} symbols")

    # Фоновая задача сброса буфера
    asyncio.ensure_future(_buffer_flush_loop())

    while True:
        try:
            await _connect_and_stream(symbols, ping_interval)
        except (ConnectionClosedError, ConnectionClosedOK) as e:
            metrics.reconnects += 1
            logger.warning(f"WS closed ({e}), reconnect in {reconnect_delay}s "
                           f"[#{metrics.reconnects}]")
        except WebSocketException as e:
            metrics.record_error()
            logger.error(f"WS error: {e}, reconnect in {reconnect_delay}s")
        except Exception as e:
            metrics.record_error()
            logger.error(f"Unexpected WS error: {e}", exc_info=True)
        finally:
            await asyncio.sleep(reconnect_delay)


async def _connect_and_stream(symbols: list[str], ping_interval: float):
    """Один WS-сеанс: подключение → подписка → стрим сообщений."""
    ws_url = config.BINGX_WS_URL

    async with websockets.connect(
        ws_url,
        ping_interval=None,      # управляем пингом вручную
        ping_timeout=10,
        close_timeout=5,
        max_size=2**23,          # 8 MB — на случай больших пакетов
        compression=None,        # BingX сам gzip-ует
        extra_headers={
            "User-Agent": "axonize-collector/1.0",
        }
    ) as ws:
        logger.info(f"WS connected: {ws_url}")

        # Подписка
        for sub_msg in build_subscribe_msg(symbols):
            await ws.send(json.dumps(sub_msg))
            await asyncio.sleep(0.05)  # небольшая пауза между batch подписками

        # Запускаем ping-поддержатель
        ping_task = asyncio.ensure_future(_ping_loop(ws, ping_interval))

        try:
            async for raw in ws:
                await _handle_message(raw)
        finally:
            ping_task.cancel()
            try:
                await ping_task
            except asyncio.CancelledError:
                pass


async def _ping_loop(ws, interval: float):
    """Отправляем ping по расписанию — BingX закрывает соединение без активности."""
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                await ws.send(json.dumps({"ping": int(time.time() * 1000)}))
                logger.debug("Ping sent")
            except Exception:
                break
    except asyncio.CancelledError:
        pass


async def _handle_message(raw):
    """Парсим сообщение и записываем в буфер."""
    metrics.record_msg()

    msg = decode_message(raw)
    if msg is None:
        return

    # Pong — ничего не делаем
    if "pong" in msg or msg.get("code") == 0 and not msg.get("data"):
        return

    candle = parse_kline(msg)
    if candle is None:
        return

    # В буфер
    write_buffer.add(candle)

    # В очередь агрегатора (только закрытые свечи)
    if candle["is_closed"] and _agg_queue is not None:
        try:
            _agg_queue.put_nowait(candle)
        except asyncio.QueueFull:
            logger.debug("Agg queue full, dropping 1m candle for agg")


async def _buffer_flush_loop():
    """Сбрасываем буфер каждые 2 секунды."""
    while True:
        await asyncio.sleep(write_buffer.FLUSH_INTERVAL)
        if write_buffer.should_flush():
            await write_buffer.flush()
