"""
AXONIZE — rest_client.py
REST досбор: исторические свечи, OI, funding rates.
Использует aiohttp с rate-limit защитой и retry.
"""
import asyncio
import hashlib
import hmac
import logging
import time
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional
from urllib.parse import urlencode

import aiohttp

import config
import database as db

logger = logging.getLogger("axonize.rest")

# ──────────────────────────────────────────────────────────────
#  Сигнатура BingX
# ──────────────────────────────────────────────────────────────

def _sign(params: dict, secret: str) -> str:
    query = urlencode(sorted(params.items()))
    return hmac.new(
        secret.encode("utf-8"),
        query.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def _signed_params(params: dict) -> dict:
    p = {"timestamp": int(time.time() * 1000), **params}
    p["signature"] = _sign(p, config.BINGX_API_SECRET)
    return p


# ──────────────────────────────────────────────────────────────
#  HTTP-клиент с retry и rate limit
# ──────────────────────────────────────────────────────────────

class BingXRestClient:
    BASE = config.BINGX_REST_BASE
    MAX_RETRIES   = 3
    RETRY_DELAY   = 2.0
    REQ_INTERVAL  = 0.05   # ~20 req/s — ниже лимитов BingX

    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._last_req = 0.0

    async def __aenter__(self):
        self._session = aiohttp.ClientSession(
            headers={
                "X-BX-APIKEY": config.BINGX_API_KEY,
                "Content-Type": "application/json",
            },
            timeout=aiohttp.ClientTimeout(total=15),
        )
        return self

    async def __aexit__(self, *_):
        if self._session:
            await self._session.close()

    async def _get(self, path: str, params: dict = None, signed: bool = False) -> dict:
        """GET с rate limit и retry."""
        p = params or {}
        if signed:
            p = _signed_params(p)

        for attempt in range(self.MAX_RETRIES):
            # Rate limit
            wait = self._last_req + self.REQ_INTERVAL - time.time()
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_req = time.time()

            try:
                async with self._session.get(f"{self.BASE}{path}", params=p) as resp:
                    if resp.status == 429:
                        retry_after = float(resp.headers.get("Retry-After", 5))
                        logger.warning(f"Rate limited, waiting {retry_after}s")
                        await asyncio.sleep(retry_after)
                        continue
                    resp.raise_for_status()
                    return await resp.json()
            except aiohttp.ClientError as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise
                logger.warning(f"REST retry {attempt+1}/{self.MAX_RETRIES}: {e}")
                await asyncio.sleep(self.RETRY_DELAY * (attempt + 1))
        return {}

    # ── Публичные методы ──────────────────────────────────────

    async def get_symbols(self) -> List[Dict]:
        """Список всех USDT-perp контрактов, отсортированных по объёму."""
        data = await self._get("/openApi/swap/v2/quote/contracts")
        contracts = data.get("data", [])
        # Фильтруем USDT-маржированные, берём топ N
        usdt = [c for c in contracts if c.get("currency") == "USDT"]
        logger.info(f"Found {len(usdt)} USDT contracts")
        return usdt[:config.TOP_SYMBOLS_COUNT]

    async def get_klines(
        self,
        symbol: str,
        interval: str,
        start_ms: int,
        end_ms: int,
        limit: int = 1000
    ) -> List[List]:
        """Исторические свечи. BingX возвращает list of [t, o, h, l, c, v]."""
        data = await self._get("/openApi/swap/v3/quote/klines", params={
            "symbol":    symbol.replace("USDT", "-USDT"),
            "interval":  interval,  # "1m", "5m" и т.д.
            "startTime": start_ms,
            "endTime":   end_ms,
            "limit":     limit,
        })
        return data.get("data", [])

    async def get_open_interest(self, symbol: str) -> Optional[Dict]:
        data = await self._get("/openApi/swap/v2/quote/openInterest", params={
            "symbol": symbol.replace("USDT", "-USDT"),
        })
        return data.get("data")

    async def get_funding_rate(self, symbol: str) -> Optional[Dict]:
        data = await self._get("/openApi/swap/v2/quote/premiumIndex", params={
            "symbol": symbol.replace("USDT", "-USDT"),
        })
        return data.get("data")


# ──────────────────────────────────────────────────────────────
#  Загрузка символов
# ──────────────────────────────────────────────────────────────

async def load_symbols() -> List[str]:
    """Получает топ-N символов и обновляет справочник в БД."""
    async with BingXRestClient() as client:
        contracts = await client.get_symbols()

    symbols_data = []
    for c in contracts:
        raw = c.get("contractId") or c.get("symbol", "")
        sym = raw.replace("-", "")
        if not sym.endswith("USDT"):
            sym = sym + "USDT"
        symbols_data.append({"symbol": sym, "baseAsset": sym.replace("USDT", "")})

    await db.upsert_symbols(symbols_data)
    symbols = [s["symbol"] for s in symbols_data]
    logger.info(f"Loaded {len(symbols)} symbols")
    return symbols


# ──────────────────────────────────────────────────────────────
#  Историческая загрузка при старте
# ──────────────────────────────────────────────────────────────

async def load_historical_candles(symbols: List[str]):
    """
    При старте коллектора: загружаем 7 дней истории 1m для всех символов.
    Параллельно: 5 символов одновременно (защита от rate limit).
    """
    logger.info(f"Loading {config.HISTORY_DAYS}d history for {len(symbols)} symbols...")

    end_ms   = int(time.time() * 1000)
    start_ms = end_ms - config.HISTORY_DAYS * 24 * 3600 * 1000
    semaphore = asyncio.Semaphore(5)  # параллелизм

    async def fetch_one(symbol: str):
        async with semaphore:
            await _fetch_symbol_history(symbol, start_ms, end_ms)

    tasks = [asyncio.create_task(fetch_one(s)) for s in symbols]
    done = 0
    for task in asyncio.as_completed(tasks):
        try:
            await task
        except Exception as e:
            logger.error(f"History load error: {e}")
        done += 1
        if done % 20 == 0:
            logger.info(f"History progress: {done}/{len(symbols)}")

    logger.info("Historical load complete")


async def _fetch_symbol_history(symbol: str, start_ms: int, end_ms: int):
    """Скачивает историю 1m по одному символу постранично."""
    async with BingXRestClient() as client:
        rows = []
        cur_start = start_ms

        while cur_start < end_ms:
            cur_end = min(cur_start + 1000 * 60 * 1000, end_ms)  # 1000 минут
            klines = await client.get_klines(symbol, "1m", cur_start, cur_end, 1000)

            if not klines:
                break

            for k in klines:
                try:
                    # [open_time, open, high, low, close, volume, close_time, quote_vol]
                    ts  = datetime.fromtimestamp(int(k[0]) / 1000, tz=timezone.utc)
                    rows.append((
                        symbol, "1m", ts,
                        float(k[1]), float(k[2]), float(k[3]), float(k[4]),
                        float(k[5]),
                        float(k[7]) if len(k) > 7 else 0.0,
                        True  # is_closed
                    ))
                except (IndexError, ValueError):
                    continue

            if len(klines) < 1000:
                break
            cur_start = int(klines[-1][0]) + 60000  # +1 минута
            await asyncio.sleep(0.1)

        if rows:
            await db.upsert_candles_bulk(rows)
            logger.debug(f"History: {symbol} — {len(rows)} candles")


# ──────────────────────────────────────────────────────────────
#  Периодический досбор OI + Funding
# ──────────────────────────────────────────────────────────────

async def run_rest_poller(symbols: List[str]):
    """
    Фоновая задача: раз в час собирает OI и Funding для всех символов.
    """
    logger.info("REST poller started")
    while True:
        await asyncio.sleep(config.OI_POLL_INTERVAL_SEC)
        try:
            await _poll_oi_and_funding(symbols)
        except Exception as e:
            logger.error(f"REST poll error: {e}", exc_info=True)


async def _poll_oi_and_funding(symbols: List[str]):
    """Параллельно запрашиваем OI и Funding для всех символов."""
    logger.info(f"Polling OI + Funding for {len(symbols)} symbols...")
    semaphore = asyncio.Semaphore(10)
    now = datetime.now(tz=timezone.utc)

    oi_rows      = []
    funding_rows = []

    async def fetch_one(symbol: str):
        async with semaphore:
            async with BingXRestClient() as client:
                # OI
                try:
                    oi = await client.get_open_interest(symbol)
                    if oi:
                        oi_rows.append({
                            "symbol":        symbol,
                            "ts":            now,
                            "oi_value":      float(oi.get("openInterest", 0)),
                            "oi_value_coin": float(oi.get("openInterestAmount", 0)),
                            "oi_change_pct": 0.0,
                        })
                except Exception as e:
                    logger.debug(f"OI error {symbol}: {e}")

                # Funding
                try:
                    fr = await client.get_funding_rate(symbol)
                    if fr:
                        next_ts = None
                        nft = fr.get("nextFundingTime")
                        if nft:
                            next_ts = datetime.fromtimestamp(int(nft)/1000, tz=timezone.utc)
                        funding_rows.append({
                            "symbol":            symbol,
                            "ts":                now,
                            "funding_rate":      float(fr.get("lastFundingRate", 0)),
                            "next_funding_time": next_ts,
                            "mark_price":        float(fr.get("markPrice", 0)),
                        })
                except Exception as e:
                    logger.debug(f"Funding error {symbol}: {e}")

    tasks = [asyncio.create_task(fetch_one(s)) for s in symbols]
    await asyncio.gather(*tasks, return_exceptions=True)

    # Запись в БД
    if oi_rows:
        await db.upsert_open_interest(oi_rows)
        logger.info(f"OI: wrote {len(oi_rows)} rows")
    if funding_rows:
        await db.upsert_funding_rates(funding_rows)
        logger.info(f"Funding: wrote {len(funding_rows)} rows")
