"""
AXONIZE — database.py
asyncpg connection pool + все методы записи в БД.
Единственный модуль, который касается PostgreSQL.
"""
import asyncio
import logging
import asyncpg
from decimal import Decimal
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

import config

logger = logging.getLogger("axonize.db")

# ──────────────────────────────────────────────────────────────
_pool: Optional[asyncpg.Pool] = None


async def init_pool() -> asyncpg.Pool:
    """Создаём connection pool при старте."""
    global _pool
    _pool = await asyncpg.create_pool(
        dsn=config.DB_DSN,
        min_size=config.DB_POOL_MIN,
        max_size=config.DB_POOL_MAX,
        command_timeout=30,
        server_settings={
            "application_name": "axonize_collector",
            "synchronous_commit": "off",   # скорость важнее при crash
        },
    )
    logger.info(f"DB pool ready: {config.DB_POOL_MIN}–{config.DB_POOL_MAX} connections")
    return _pool


async def close_pool():
    if _pool:
        await _pool.close()


def get_pool() -> asyncpg.Pool:
    if _pool is None:
        raise RuntimeError("DB pool not initialized. Call init_pool() first.")
    return _pool


# ──────────────────────────────────────────────────────────────
#  CANDLES
# ──────────────────────────────────────────────────────────────

UPSERT_CANDLE = """
INSERT INTO candles (symbol, timeframe, ts, open, high, low, close, volume, quote_volume, is_closed)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
ON CONFLICT (symbol, timeframe, ts) DO UPDATE SET
    high         = GREATEST(EXCLUDED.high, candles.high),
    low          = LEAST(EXCLUDED.low, candles.low),
    close        = EXCLUDED.close,
    volume       = EXCLUDED.volume,
    quote_volume = EXCLUDED.quote_volume,
    is_closed    = EXCLUDED.is_closed
"""

async def upsert_candle(
    symbol: str, timeframe: str, ts: datetime,
    o: float, h: float, l: float, c: float,
    vol: float, quote_vol: float = 0.0, is_closed: bool = False
):
    """Один тик — один upsert. Вызывается из WS handler."""
    async with get_pool().acquire() as conn:
        await conn.execute(
            UPSERT_CANDLE,
            symbol, timeframe, ts,
            Decimal(str(o)), Decimal(str(h)),
            Decimal(str(l)), Decimal(str(c)),
            Decimal(str(vol)), Decimal(str(quote_vol)),
            is_closed
        )


async def upsert_candles_bulk(rows: List[tuple]):
    """
    Пакетная запись свечей — для исторической загрузки и агрегации.
    rows: list of (symbol, timeframe, ts, o, h, l, c, vol, quote_vol, is_closed)
    """
    if not rows:
        return
    async with get_pool().acquire() as conn:
        await conn.executemany(UPSERT_CANDLE, rows)
    logger.debug(f"Bulk upsert {len(rows)} candles")


# ──────────────────────────────────────────────────────────────
#  OPEN INTEREST
# ──────────────────────────────────────────────────────────────

async def upsert_open_interest(rows: List[Dict]):
    """
    rows: [{"symbol": ..., "ts": ..., "oi_value": ..., "oi_value_coin": ..., "oi_change_pct": ...}]
    """
    sql = """
    INSERT INTO open_interest (symbol, ts, oi_value, oi_value_coin, oi_change_pct)
    VALUES ($1, $2, $3, $4, $5)
    ON CONFLICT (symbol, ts) DO UPDATE SET
        oi_value      = EXCLUDED.oi_value,
        oi_value_coin = EXCLUDED.oi_value_coin,
        oi_change_pct = EXCLUDED.oi_change_pct
    """
    data = [
        (r["symbol"], r["ts"],
         Decimal(str(r.get("oi_value", 0))),
         Decimal(str(r.get("oi_value_coin", 0))),
         Decimal(str(r.get("oi_change_pct", 0))))
        for r in rows
    ]
    async with get_pool().acquire() as conn:
        await conn.executemany(sql, data)


# ──────────────────────────────────────────────────────────────
#  FUNDING RATES
# ──────────────────────────────────────────────────────────────

async def upsert_funding_rates(rows: List[Dict]):
    sql = """
    INSERT INTO funding_rates (symbol, ts, funding_rate, next_funding_time, mark_price)
    VALUES ($1, $2, $3, $4, $5)
    ON CONFLICT (symbol, ts) DO UPDATE SET
        funding_rate     = EXCLUDED.funding_rate,
        next_funding_time = EXCLUDED.next_funding_time,
        mark_price       = EXCLUDED.mark_price
    """
    data = [
        (r["symbol"], r["ts"],
         Decimal(str(r.get("funding_rate", 0))),
         r.get("next_funding_time"),
         Decimal(str(r.get("mark_price", 0))))
        for r in rows
    ]
    async with get_pool().acquire() as conn:
        await conn.executemany(sql, data)


# ──────────────────────────────────────────────────────────────
#  TRADES AGGREGATED  (delta объём)
# ──────────────────────────────────────────────────────────────

async def upsert_trade_volume(
    symbol: str, ts: datetime,
    buy_vol: float, sell_vol: float,
    buy_count: int = 0, sell_count: int = 0
):
    sql = """
    INSERT INTO trades_aggregated (symbol, ts, buy_vol, sell_vol, buy_count, sell_count)
    VALUES ($1, $2, $3, $4, $5, $6)
    ON CONFLICT (symbol, ts) DO UPDATE SET
        buy_vol    = trades_aggregated.buy_vol  + EXCLUDED.buy_vol,
        sell_vol   = trades_aggregated.sell_vol + EXCLUDED.sell_vol,
        buy_count  = trades_aggregated.buy_count  + EXCLUDED.buy_count,
        sell_count = trades_aggregated.sell_count + EXCLUDED.sell_count
    """
    async with get_pool().acquire() as conn:
        await conn.execute(
            sql, symbol, ts,
            Decimal(str(buy_vol)), Decimal(str(sell_vol)),
            buy_count, sell_count
        )


# ──────────────────────────────────────────────────────────────
#  TICKER PRICES
# ──────────────────────────────────────────────────────────────

async def upsert_ticker_latest(rows: List[Dict]):
    """
    Обновляет ticker_latest (1 строка на символ) — для live цен в терминале.
    """
    sql = """
    INSERT INTO ticker_latest (symbol, ts, price, price_change, volume_24h, high_24h, low_24h)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    ON CONFLICT (symbol) DO UPDATE SET
        ts           = EXCLUDED.ts,
        price        = EXCLUDED.price,
        price_change = EXCLUDED.price_change,
        volume_24h   = EXCLUDED.volume_24h,
        high_24h     = EXCLUDED.high_24h,
        low_24h      = EXCLUDED.low_24h
    """
    data = [
        (r["symbol"], r["ts"],
         Decimal(str(r.get("price", 0))),
         Decimal(str(r.get("price_change", 0))),
         Decimal(str(r.get("volume_24h", 0))),
         Decimal(str(r.get("high_24h", 0))),
         Decimal(str(r.get("low_24h", 0))))
        for r in rows
    ]
    async with get_pool().acquire() as conn:
        await conn.executemany(sql, data)


# ──────────────────────────────────────────────────────────────
#  HELPERS — чтение для агрегатора
# ──────────────────────────────────────────────────────────────

async def get_1m_candles_for_agg(
    symbol: str,
    since: datetime,
    until: datetime
) -> List[asyncpg.Record]:
    """Читает 1m свечи для агрегации в старшие таймфреймы."""
    sql = """
    SELECT ts, open, high, low, close, volume, quote_volume
    FROM candles
    WHERE symbol = $1 AND timeframe = '1m'
      AND ts >= $2 AND ts < $3
      AND is_closed = TRUE
    ORDER BY ts ASC
    """
    async with get_pool().acquire() as conn:
        return await conn.fetch(sql, symbol, since, until)


async def get_active_symbols() -> List[str]:
    """Возвращает список активных символов из справочника."""
    async with get_pool().acquire() as conn:
        rows = await conn.fetch(
            "SELECT symbol FROM symbols WHERE is_active = TRUE ORDER BY volume_rank"
        )
        return [r["symbol"] for r in rows]


async def upsert_symbols(symbols_data: List[Dict]):
    """Обновляет справочник символов."""
    sql = """
    INSERT INTO symbols (symbol, base_asset, quote_asset, volume_rank)
    VALUES ($1, $2, $3, $4)
    ON CONFLICT (symbol) DO UPDATE SET
        volume_rank = EXCLUDED.volume_rank,
        is_active   = TRUE,
        updated_at  = NOW()
    """
    data = [
        (s["symbol"], s.get("baseAsset", s["symbol"].replace("USDT","")), "USDT", i)
        for i, s in enumerate(symbols_data)
    ]
    async with get_pool().acquire() as conn:
        await conn.executemany(sql, data)


async def write_collector_status(status: Dict):
    sql = """
    INSERT INTO collector_status
        (ws_connected, symbols_count, msgs_per_sec, db_writes_total, errors_count, uptime_sec)
    VALUES ($1, $2, $3, $4, $5, $6)
    """
    async with get_pool().acquire() as conn:
        await conn.execute(
            sql,
            status.get("ws_connected", False),
            status.get("symbols_count", 0),
            status.get("msgs_per_sec", 0.0),
            status.get("db_writes_total", 0),
            status.get("errors_count", 0),
            status.get("uptime_sec", 0),
        )
