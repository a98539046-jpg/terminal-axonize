"""
AXONIZE BingX Collector — config.py
Загружает .env и предоставляет настройки всем модулям.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── PostgreSQL ──────────────────────────────────────────────
DB_HOST     = os.getenv("DB_HOST", "localhost")
DB_PORT     = int(os.getenv("DB_PORT", 5432))
DB_NAME     = os.getenv("DB_NAME", "trading_terminal")
DB_USER     = os.getenv("DB_USER", "axonize")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_POOL_MIN = int(os.getenv("DB_POOL_MIN", 5))
DB_POOL_MAX = int(os.getenv("DB_POOL_MAX", 20))

DB_DSN = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# ── BingX ────────────────────────────────────────────────────
BINGX_API_KEY    = os.getenv("BINGX_API_KEY", "")
BINGX_API_SECRET = os.getenv("BINGX_API_SECRET", "")
BINGX_WS_URL     = os.getenv("BINGX_WS_URL", "wss://open-api-swap.bingx.com/swap-market")
BINGX_REST_BASE  = "https://open-api.bingx.com"

# ── Collector ────────────────────────────────────────────────
TOP_SYMBOLS_COUNT    = int(os.getenv("TOP_SYMBOLS_COUNT", 200))
RECONNECT_DELAY_MS   = int(os.getenv("RECONNECT_DELAY_MS", 1000))
WS_PING_INTERVAL_MS  = int(os.getenv("WS_PING_INTERVAL_MS", 20000))
HISTORY_DAYS         = int(os.getenv("HISTORY_DAYS", 7))
AGG_TIMEFRAMES       = os.getenv("AGG_TIMEFRAMES", "5m,15m,1h,4h").split(",")

# ── Polling ──────────────────────────────────────────────────
OI_POLL_INTERVAL_SEC      = int(os.getenv("OI_POLL_INTERVAL_MS", 3600000)) // 1000
FUNDING_POLL_INTERVAL_SEC = int(os.getenv("FUNDING_POLL_INTERVAL_MS", 3600000)) // 1000

# ── Timeframe в минутах ──────────────────────────────────────
TF_MINUTES = {
    "1m": 1, "5m": 5, "15m": 15, "30m": 30,
    "1h": 60, "4h": 240, "1d": 1440
}

# ── Logging ──────────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "info").upper()
LOG_FILE  = os.getenv("LOG_FILE", "/var/log/axonize-collector.log")
