-- ============================================================
--  AXONIZE trading_terminal — PostgreSQL Schema
--  Запуск: psql -U postgres -f schema.sql
-- ============================================================

-- Создаём пользователя и БД
DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'axonize') THEN
    CREATE ROLE axonize WITH LOGIN PASSWORD 'your_secure_password_here';
  END IF;
END $$;

CREATE DATABASE trading_terminal OWNER axonize;
\c trading_terminal

-- Расширения
CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;  -- опционально (TimescaleDB)
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- ============================================================
--  ТАБЛИЦА: candles
--  Хранит 1m свечи и агрегированные (5m/15m/1h/4h/1d)
-- ============================================================
CREATE TABLE IF NOT EXISTS candles (
    id            BIGSERIAL,
    symbol        VARCHAR(20)  NOT NULL,
    timeframe     VARCHAR(5)   NOT NULL,  -- '1m','5m','15m','1h','4h','1d'
    ts            TIMESTAMPTZ  NOT NULL,  -- открытие свечи
    open          NUMERIC(20,8) NOT NULL,
    high          NUMERIC(20,8) NOT NULL,
    low           NUMERIC(20,8) NOT NULL,
    close         NUMERIC(20,8) NOT NULL,
    volume        NUMERIC(24,4) NOT NULL,
    quote_volume  NUMERIC(24,4) DEFAULT 0,
    trades_count  INTEGER DEFAULT 0,
    is_closed     BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (symbol, timeframe, ts)
) PARTITION BY RANGE (ts);

-- Партиции по месяцам (создаём на 6 месяцев вперёд)
CREATE TABLE candles_2025_01 PARTITION OF candles
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
CREATE TABLE candles_2025_02 PARTITION OF candles
    FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');
CREATE TABLE candles_2025_03 PARTITION OF candles
    FOR VALUES FROM ('2025-03-01') TO ('2025-04-01');
CREATE TABLE candles_2025_04 PARTITION OF candles
    FOR VALUES FROM ('2025-04-01') TO ('2025-05-01');
CREATE TABLE candles_2025_05 PARTITION OF candles
    FOR VALUES FROM ('2025-05-01') TO ('2025-06-01');
CREATE TABLE candles_2025_06 PARTITION OF candles
    FOR VALUES FROM ('2025-06-01') TO ('2025-07-01');
CREATE TABLE candles_2025_07 PARTITION OF candles
    FOR VALUES FROM ('2025-07-01') TO ('2025-08-01');
CREATE TABLE candles_2025_08 PARTITION OF candles
    FOR VALUES FROM ('2025-08-01') TO ('2025-09-01');
CREATE TABLE candles_2025_09 PARTITION OF candles
    FOR VALUES FROM ('2025-09-01') TO ('2025-10-01');
CREATE TABLE candles_2025_10 PARTITION OF candles
    FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');
CREATE TABLE candles_2025_11 PARTITION OF candles
    FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');
CREATE TABLE candles_2025_12 PARTITION OF candles
    FOR VALUES FROM ('2025-12-01') TO ('2026-01-01');
CREATE TABLE candles_2026_01 PARTITION OF candles
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
CREATE TABLE candles_2026_02 PARTITION OF candles
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');
CREATE TABLE candles_2026_03 PARTITION OF candles
    FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');
CREATE TABLE candles_2026_04 PARTITION OF candles
    FOR VALUES FROM ('2026-04-01') TO ('2026-05-01');
CREATE TABLE candles_2026_05 PARTITION OF candles
    FOR VALUES FROM ('2026-05-01') TO ('2026-06-01');
CREATE TABLE candles_2026_06 PARTITION OF candles
    FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');

-- Индексы на candles
CREATE INDEX idx_candles_symbol_tf_ts
    ON candles (symbol, timeframe, ts DESC);
CREATE INDEX idx_candles_ts
    ON candles (ts DESC);
CREATE INDEX idx_candles_symbol_ts
    ON candles (symbol, ts DESC);

-- ============================================================
--  ТАБЛИЦА: open_interest
-- ============================================================
CREATE TABLE IF NOT EXISTS open_interest (
    symbol          VARCHAR(20)   NOT NULL,
    ts              TIMESTAMPTZ   NOT NULL,
    oi_value        NUMERIC(24,4) NOT NULL,  -- в USDT
    oi_value_coin   NUMERIC(24,8) DEFAULT 0, -- в монете
    oi_change_pct   NUMERIC(10,4) DEFAULT 0, -- % изменение
    PRIMARY KEY (symbol, ts)
);

CREATE INDEX idx_oi_symbol_ts ON open_interest (symbol, ts DESC);

-- ============================================================
--  ТАБЛИЦА: funding_rates
-- ============================================================
CREATE TABLE IF NOT EXISTS funding_rates (
    symbol        VARCHAR(20)   NOT NULL,
    ts            TIMESTAMPTZ   NOT NULL,
    funding_rate  NUMERIC(14,8) NOT NULL,
    next_funding_time TIMESTAMPTZ,
    mark_price    NUMERIC(20,8) DEFAULT 0,
    PRIMARY KEY (symbol, ts)
);

CREATE INDEX idx_funding_symbol_ts ON funding_rates (symbol, ts DESC);

-- ============================================================
--  ТАБЛИЦА: trades_aggregated
--  Агрегированные сделки по 1-минутным бакетам
-- ============================================================
CREATE TABLE IF NOT EXISTS trades_aggregated (
    symbol        VARCHAR(20)   NOT NULL,
    ts            TIMESTAMPTZ   NOT NULL,  -- бакет (1m)
    buy_vol       NUMERIC(24,4) NOT NULL DEFAULT 0,
    sell_vol      NUMERIC(24,4) NOT NULL DEFAULT 0,
    buy_count     INTEGER       DEFAULT 0,
    sell_count    INTEGER       DEFAULT 0,
    total_vol     NUMERIC(24,4) GENERATED ALWAYS AS (buy_vol + sell_vol) STORED,
    delta         NUMERIC(24,4) GENERATED ALWAYS AS (buy_vol - sell_vol) STORED,
    PRIMARY KEY (symbol, ts)
);

CREATE INDEX idx_trades_agg_symbol_ts ON trades_aggregated (symbol, ts DESC);

-- ============================================================
--  ТАБЛИЦА: ticker_prices
--  Текущие цены — для live отображения в терминале
-- ============================================================
CREATE TABLE IF NOT EXISTS ticker_prices (
    symbol        VARCHAR(20)   NOT NULL,
    ts            TIMESTAMPTZ   NOT NULL,
    price         NUMERIC(20,8) NOT NULL,
    price_change  NUMERIC(10,4) DEFAULT 0,  -- % за 24ч
    volume_24h    NUMERIC(24,4) DEFAULT 0,
    high_24h      NUMERIC(20,8) DEFAULT 0,
    low_24h       NUMERIC(20,8) DEFAULT 0,
    oi            NUMERIC(24,4) DEFAULT 0,
    funding_rate  NUMERIC(14,8) DEFAULT 0,
    PRIMARY KEY (symbol, ts)
);

CREATE INDEX idx_ticker_symbol_ts ON ticker_prices (symbol, ts DESC);

-- Отдельная таблица для ТЕКУЩИХ цен (upsert) — 1 строка на символ
CREATE TABLE IF NOT EXISTS ticker_latest (
    symbol        VARCHAR(20)   PRIMARY KEY,
    ts            TIMESTAMPTZ   NOT NULL,
    price         NUMERIC(20,8) NOT NULL,
    price_change  NUMERIC(10,4) DEFAULT 0,
    volume_24h    NUMERIC(24,4) DEFAULT 0,
    high_24h      NUMERIC(20,8) DEFAULT 0,
    low_24h       NUMERIC(20,8) DEFAULT 0,
    oi            NUMERIC(24,4) DEFAULT 0,
    funding_rate  NUMERIC(14,8) DEFAULT 0
);

-- ============================================================
--  ТАБЛИЦА: symbols (справочник)
-- ============================================================
CREATE TABLE IF NOT EXISTS symbols (
    symbol        VARCHAR(20)   PRIMARY KEY,
    base_asset    VARCHAR(10)   NOT NULL,
    quote_asset   VARCHAR(10)   NOT NULL DEFAULT 'USDT',
    volume_rank   INTEGER       DEFAULT 9999,
    is_active     BOOLEAN       DEFAULT TRUE,
    updated_at    TIMESTAMPTZ   DEFAULT NOW()
);

-- ============================================================
--  ТАБЛИЦА: collector_status (мониторинг)
-- ============================================================
CREATE TABLE IF NOT EXISTS collector_status (
    id              SERIAL PRIMARY KEY,
    ts              TIMESTAMPTZ DEFAULT NOW(),
    ws_connected    BOOLEAN DEFAULT FALSE,
    symbols_count   INTEGER DEFAULT 0,
    msgs_per_sec    NUMERIC(10,2) DEFAULT 0,
    db_writes_total BIGINT DEFAULT 0,
    errors_count    INTEGER DEFAULT 0,
    uptime_sec      INTEGER DEFAULT 0
);

-- ============================================================
--  VIEWS — удобные запросы для терминала
-- ============================================================

-- Последняя 1m свеча для каждого символа
CREATE OR REPLACE VIEW v_latest_candles AS
SELECT DISTINCT ON (symbol)
    symbol, ts, open, high, low, close, volume, is_closed
FROM candles
WHERE timeframe = '1m'
ORDER BY symbol, ts DESC;

-- Топ монет по объёму за последние 24ч
CREATE OR REPLACE VIEW v_top_volume AS
SELECT
    symbol,
    SUM(volume) AS vol_24h,
    COUNT(*)    AS candles_count,
    MIN(low)    AS low_24h,
    MAX(high)   AS high_24h
FROM candles
WHERE timeframe = '1m'
  AND ts >= NOW() - INTERVAL '24 hours'
GROUP BY symbol
ORDER BY vol_24h DESC;

-- ============================================================
--  Права
-- ============================================================
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO axonize;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO axonize;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO axonize;

\echo '✓ Schema created successfully'
