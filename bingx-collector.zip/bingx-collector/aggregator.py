"""
AXONIZE — aggregator.py
Агрегирует 1m свечи в 5m / 15m / 1h / 4h в реальном времени.
Работает через asyncio.Queue — получает закрытые 1m свечи от ws_collector.
Не зависит от REST API.
"""
import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional
from dataclasses import dataclass, field
from math import floor

import config
import database as db

logger = logging.getLogger("axonize.agg")


# ──────────────────────────────────────────────────────────────
#  Структура аккумулятора одной агрегированной свечи
# ──────────────────────────────────────────────────────────────

@dataclass
class AggCandle:
    symbol:    str
    timeframe: str
    ts:        datetime          # открытие бакета
    open:      float = 0.0
    high:      float = 0.0
    low:       float = float("inf")
    close:     float = 0.0
    volume:    float = 0.0
    quote_vol: float = 0.0
    count:     int   = 0

    def update(self, candle: dict):
        """Обновляем аккумулятор данными новой 1m свечи."""
        if self.count == 0:
            self.open = candle["open"]
        self.high      = max(self.high, candle["high"])
        self.low       = min(self.low,  candle["low"])
        self.close     = candle["close"]
        self.volume   += candle["volume"]
        self.quote_vol += candle["quote_vol"]
        self.count    += 1

    def to_db_row(self) -> tuple:
        return (
            self.symbol, self.timeframe, self.ts,
            self.open, self.high, self.low, self.close,
            self.volume, self.quote_vol, True  # is_closed=True
        )


# ──────────────────────────────────────────────────────────────
#  Вычисление начала бакета для каждого таймфрейма
# ──────────────────────────────────────────────────────────────

def bucket_start(ts: datetime, tf: str) -> datetime:
    """
    Возвращает начало бакета для данного таймфрейма.
    ts — timestamp открытия 1m свечи (уже UTC).
    """
    minutes = config.TF_MINUTES[tf]
    epoch   = ts.timestamp()
    bucket  = floor(epoch / (minutes * 60)) * (minutes * 60)
    return datetime.fromtimestamp(bucket, tz=timezone.utc)


# ──────────────────────────────────────────────────────────────
#  Агрегатор
# ──────────────────────────────────────────────────────────────

class CandleAggregator:
    """
    Состояние: словарь (symbol, timeframe) → AggCandle (текущий бакет).
    При получении 1m свечи:
      1. Для каждого старшего TF вычисляем бакет.
      2. Если symbol+tf+bucket_ts уже есть — update().
      3. Если нет — текущий бакет закрылся → пишем в БД, создаём новый.
    """

    def __init__(self, timeframes: list[str]):
        self.timeframes = [tf for tf in timeframes if tf in config.TF_MINUTES]
        # (symbol, timeframe) → AggCandle
        self._state: Dict[tuple, AggCandle] = {}
        self._pending_writes: list[tuple] = []
        self._writes_count = 0

    def process(self, candle_1m: dict) -> list[tuple]:
        """
        Обрабатываем одну закрытую 1m свечу.
        Возвращает список строк, готовых к записи в БД.
        """
        symbol = candle_1m["symbol"]
        ts_1m  = candle_1m["ts"]
        ready_rows = []

        for tf in self.timeframes:
            key        = (symbol, tf)
            bucket_ts  = bucket_start(ts_1m, tf)

            existing = self._state.get(key)

            if existing is None:
                # Первая свеча для этого символа и TF
                agg = AggCandle(symbol=symbol, timeframe=tf, ts=bucket_ts)
                agg.update(candle_1m)
                self._state[key] = agg

            elif existing.ts == bucket_ts:
                # Та же свеча — обновляем
                existing.update(candle_1m)

            else:
                # Новый бакет — закрываем старый
                ready_rows.append(existing.to_db_row())
                agg = AggCandle(symbol=symbol, timeframe=tf, ts=bucket_ts)
                agg.update(candle_1m)
                self._state[key] = agg

        return ready_rows


# ──────────────────────────────────────────────────────────────
#  Фоновый worker — читает из очереди и пишет в БД
# ──────────────────────────────────────────────────────────────

async def run_aggregator(queue: asyncio.Queue):
    """
    Запускается как отдельная asyncio-задача.
    queue — asyncio.Queue, в которую ws_collector кидает закрытые 1m свечи.
    """
    agg = CandleAggregator(config.AGG_TIMEFRAMES)
    batch: list[tuple] = []
    BATCH_SIZE    = 200
    FLUSH_TIMEOUT = 5.0  # сброс раз в N секунд даже если батч не полный

    logger.info(f"Aggregator started | TFs: {config.AGG_TIMEFRAMES}")

    last_flush = asyncio.get_event_loop().time()

    while True:
        try:
            # Ждём свечу с таймаутом (чтобы не застрять при низкой нагрузке)
            try:
                candle_1m = await asyncio.wait_for(queue.get(), timeout=FLUSH_TIMEOUT)
                rows = agg.process(candle_1m)
                batch.extend(rows)
                queue.task_done()
            except asyncio.TimeoutError:
                pass

            # Flush по размеру или таймауту
            now = asyncio.get_event_loop().time()
            if len(batch) >= BATCH_SIZE or (now - last_flush) >= FLUSH_TIMEOUT:
                if batch:
                    await _flush_batch(batch)
                    batch = []
                    last_flush = now

        except asyncio.CancelledError:
            # Graceful shutdown — сбрасываем остатки
            if batch:
                await _flush_batch(batch)
            logger.info("Aggregator stopped")
            return
        except Exception as e:
            logger.error(f"Aggregator error: {e}", exc_info=True)
            await asyncio.sleep(1)


async def _flush_batch(rows: list[tuple]):
    try:
        await db.upsert_candles_bulk(rows)
        logger.debug(f"Aggregator: flushed {len(rows)} rows")
    except Exception as e:
        logger.error(f"Aggregator DB write error: {e}")
