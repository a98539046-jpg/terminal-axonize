#!/usr/bin/env bash
# ============================================================
#  AXONIZE — deploy.sh
#  Установка и запуск коллектора на VPS (Ubuntu 22+)
#  Запуск: bash deploy.sh
# ============================================================
set -e

COLLECTOR_DIR="/root/bingx-collector"
SERVICE_NAME="axonize-collector"
PG_DB="trading_terminal"
PG_USER="axonize"

echo "═══════════════════════════════════════════════"
echo "  AXONIZE BingX Collector — Deploy Script"
echo "═══════════════════════════════════════════════"

# ── 1. Зависимости системы ─────────────────────────────────
echo "[1/7] Installing system dependencies..."
apt-get update -qq
apt-get install -y -qq python3.11 python3.11-venv python3-pip \
    postgresql postgresql-contrib curl

# ── 2. PostgreSQL ──────────────────────────────────────────
echo "[2/7] Setting up PostgreSQL..."
systemctl enable postgresql
systemctl start postgresql

# Ждём готовности
sleep 2

# Создаём пользователя и БД (если не существуют)
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$PG_USER'" | \
    grep -q 1 || \
    sudo -u postgres psql -c "CREATE ROLE $PG_USER WITH LOGIN PASSWORD 'change_me_in_env';"

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$PG_DB'" | \
    grep -q 1 || \
    sudo -u postgres createdb -O "$PG_USER" "$PG_DB"

# ── 3. Применяем схему ────────────────────────────────────
echo "[3/7] Applying DB schema..."
sudo -u postgres psql -d "$PG_DB" -f "$COLLECTOR_DIR/sql/schema.sql"

# ── 4. Python venv ─────────────────────────────────────────
echo "[4/7] Setting up Python virtualenv..."
cd "$COLLECTOR_DIR"
python3.11 -m venv venv
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt

# ── 5. .env ────────────────────────────────────────────────
echo "[5/7] Checking .env..."
if [ ! -f "$COLLECTOR_DIR/.env" ]; then
    cp "$COLLECTOR_DIR/.env.example" "$COLLECTOR_DIR/.env"
    echo "  ⚠  Created .env from example — EDIT IT before starting!"
    echo "     nano $COLLECTOR_DIR/.env"
else
    echo "  ✓ .env exists"
fi

# ── 6. systemd service ─────────────────────────────────────
echo "[6/7] Creating systemd service..."
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=AXONIZE BingX Real-Time Collector
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=${COLLECTOR_DIR}
ExecStart=${COLLECTOR_DIR}/venv/bin/python main.py
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

# Ограничения
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"

# ── 7. Логи ────────────────────────────────────────────────
echo "[7/7] Setting up log rotation..."
cat > /etc/logrotate.d/axonize-collector << EOF
/var/log/axonize-collector.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 640 root root
}
EOF

touch /var/log/axonize-collector.log

echo ""
echo "═══════════════════════════════════════════════"
echo "  ✓ Deploy complete!"
echo ""
echo "  Следующие шаги:"
echo "  1. Отредактируй .env:  nano $COLLECTOR_DIR/.env"
echo "     - DB_PASSWORD"
echo "     - BINGX_API_KEY"
echo "     - BINGX_API_SECRET"
echo ""
echo "  2. Запусти: systemctl start $SERVICE_NAME"
echo "  3. Логи:    journalctl -u $SERVICE_NAME -f"
echo "              tail -f /var/log/axonize-collector.log"
echo ""
echo "  PM2 (альтернатива systemd):"
echo "  pm2 start venv/bin/python --name collector -- main.py"
echo "  pm2 save"
echo "═══════════════════════════════════════════════"
