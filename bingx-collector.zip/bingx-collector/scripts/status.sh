#!/usr/bin/env bash
# ============================================================
#  AXONIZE — status.sh
#  Проверка состояния коллектора
#  Запуск: bash scripts/status.sh
# ============================================================

DB="trading_terminal"
USER="axonize"

echo "═══════════════════════════════════════════════"
echo "  AXONIZE Collector Status"
echo "═══════════════════════════════════════════════"
echo ""

# systemd status
echo "── systemd ────────────────────────────────────"
systemctl is-active axonize-collector 2>/dev/null && \
    echo "  ✓ axonize-collector: RUNNING" || \
    echo "  ✗ axonize-collector: STOPPED"
echo ""

# PM2 (если используется)
if command -v pm2 &>/dev/null; then
    echo "── PM2 ────────────────────────────────────────"
    pm2 status collector 2>/dev/null || echo "  Not running via PM2"
    echo ""
fi

# DB stats
echo "── PostgreSQL ─────────────────────────────────"
psql -U "$USER" -d "$DB" -c "
SELECT
  (SELECT COUNT(DISTINCT symbol) FROM candles WHERE timeframe='1m') AS symbols_1m,
  (SELECT COUNT(*) FROM candles WHERE timeframe='1m') AS total_1m_candles,
  (SELECT COUNT(*) FROM candles WHERE timeframe='1m'
     AND ts > NOW() - INTERVAL '5 minutes') AS candles_last_5m,
  (SELECT COUNT(*) FROM open_interest) AS oi_records,
  (SELECT COUNT(*) FROM funding_rates) AS funding_records;
" 2>/dev/null || echo "  DB not accessible"

echo ""
echo "── Latest collector status ────────────────────"
psql -U "$USER" -d "$DB" -c "
SELECT ts, ws_connected, symbols_count,
       msgs_per_sec, db_writes_total, errors_count, uptime_sec
FROM collector_status
ORDER BY ts DESC
LIMIT 3;
" 2>/dev/null

echo ""
echo "── Candle freshness (last 1m candle per symbol) ──"
psql -U "$USER" -d "$DB" -c "
SELECT symbol, MAX(ts) AS last_candle,
       EXTRACT(EPOCH FROM (NOW() - MAX(ts)))::INT AS seconds_ago
FROM candles
WHERE timeframe = '1m'
GROUP BY symbol
ORDER BY seconds_ago DESC
LIMIT 5;
" 2>/dev/null

echo ""
echo "═══════════════════════════════════════════════"
