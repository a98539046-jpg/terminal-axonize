"""
AXONIZE — main.py
Точка входа. Запускает все компоненты:
  - DB pool
  - Историческая загрузка (7d)
  - WebSocket коллектор (топ 200 символов)
  - Агрегатор 5m/15m/1h/4h
  - REST poller (OI + Funding, раз в час)
  - Мониторинг (статус в БД каждые 60 сек)

Запуск: python main.py
"""
import asyncio
import logging
import signal
import sys
import time
from logging.handlers import RotatingFileHandler

import config
import database as db
from ws_collector import run_ws_collector, set_agg_queue, metrics
from aggregator import run_aggregator
from rest_client import load_symbols, load_historical_candles, run_rest_poller


# ──────────────────────────────────────────────────────────────
#  Logging setup
# ──────────────────────────────────────────────────────────────

def setup_logging():
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    level = getattr(logging, config.LOG_LEVEL, logging.INFO)

    handlers = [logging.StreamHandler(sys.stdout)]

    try:
        file_handler = RotatingFileHandler(
            config.LOG_FILE,
            maxBytes=50 * 1024 * 1024,  # 50 MB
            backupCount=5,
            encoding="utf-8"
        )
        handlers.append(file_handler)
    except Exception as e:
        print(f"Warning: can't write log to {config.LOG_FILE}: {e}")

    logging.basicConfig(level=level, format=fmt, handlers=handlers)

    # Приглушаем шумные либы
    logging.getLogger("websockets").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


logger = logging.getLogger("axonize.main")


# ──────────────────────────────────────────────────────────────
#  Мониторинг — пишем статус в БД
# ──────────────────────────────────────────────────────────────

async def run_monitor(symbols_count: int):
    """Каждые 60 секунд пишем метрики в collector_status."""
    while True:
        await asyncio.sleep(60)
        try:
            await db.write_collector_status({
                "ws_connected":   True,
                "symbols_count":  symbols_count,
                "msgs_per_sec":   round(metrics.msgs_per_sec, 2),
                "db_writes_total": metrics.writes_total,
                "errors_count":   metrics.errors_total,
                "uptime_sec":     metrics.uptime_sec,
            })
            logger.info(
                f"[MONITOR] uptime={metrics.uptime_sec}s | "
                f"msgs/s={metrics.msgs_per_sec:.1f} | "
                f"writes={metrics.writes_total} | "
                f"errors={metrics.errors_total} | "
                f"reconnects={metrics.reconnects}"
            )
        except Exception as e:
            logger.error(f"Monitor write error: {e}")


# ──────────────────────────────────────────────────────────────
#  Graceful shutdown
# ──────────────────────────────────────────────────────────────

_shutdown_event = asyncio.Event()

def _handle_signal(sig):
    logger.info(f"Signal {sig.name} received, shutting down...")
    _shutdown_event.set()


# ──────────────────────────────────────────────────────────────
#  Main
# ──────────────────────────────────────────────────────────────

async def main():
    setup_logging()
    logger.info("=" * 60)
    logger.info("  AXONIZE BingX Collector starting")
    logger.info("=" * 60)

    # Signals
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, lambda s=sig: _handle_signal(s))

    # 1. DB pool
    logger.info("Connecting to PostgreSQL...")
    await db.init_pool()
    logger.info("DB pool ready")

    # 2. Загрузка символов (топ 200)
    logger.info("Fetching top symbols from BingX...")
    try:
        symbols = await load_symbols()
    except Exception as e:
        logger.error(f"Failed to load symbols: {e}")
        logger.info("Using cached symbols from DB...")
        symbols = await db.get_active_symbols()
        if not symbols:
            logger.critical("No symbols available. Check BingX API key.")
            sys.exit(1)

    logger.info(f"Symbols loaded: {len(symbols)}")

    # 3. Историческая загрузка (7 дней) в фоне (не блокируем WS)
    hist_task = asyncio.create_task(
        load_historical_candles(symbols),
        name="historical_load"
    )

    # 4. Очередь между WS коллектором и агрегатором
    agg_queue = asyncio.Queue(maxsize=10000)
    set_agg_queue(agg_queue)

    # 5. Запускаем все фоновые задачи
    tasks = [
        asyncio.create_task(run_ws_collector(symbols),  name="ws_collector"),
        asyncio.create_task(run_aggregator(agg_queue),  name="aggregator"),
        asyncio.create_task(run_rest_poller(symbols),   name="rest_poller"),
        asyncio.create_task(run_monitor(len(symbols)),  name="monitor"),
        hist_task,
    ]

    logger.info(f"All tasks started. Collecting {len(symbols)} symbols.")
    logger.info(f"Timeframes: 1m (live) + {config.AGG_TIMEFRAMES} (aggregated)")

    # Ждём сигнала завершения или падения задачи
    done_task, _ = await asyncio.wait(
        [*tasks, asyncio.create_task(_shutdown_event.wait())],
        return_when=asyncio.FIRST_COMPLETED
    )

    logger.info("Shutting down tasks...")
    for task in tasks:
        if not task.done():
            task.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)
    await db.close_pool()
    logger.info("Collector stopped cleanly.")


if __name__ == "__main__":
    asyncio.run(main())
